﻿--Exercise 1: Querying and Filtering Data
--1 : Write a query that retrieves the columns ProductID, Name, Color and ListPrice from the Production.Product table, with no filter.
SELECT P.ProductID, P.Name,P.Color, P.ListPrice
FROM Production.Product P;
GO
--2 : Continue to work with the previous query and exclude those rows that are 0 for the column ListPrice.
SELECT P.ProductID, P.Name,P.Color, P.ListPrice
FROM Production.Product P
WHERE P.ListPrice != 0;
GO
-- 3 : Use the same query, but this time you just want to see the rows that are NULL for the Color column.
SELECT P.ProductID, P.Name,P.Color, P.ListPrice
FROM Production.Product P
WHERE P.Color is null;
GO
-- 4 : Use the same query, but this time you just want to see the rows that are not NULL for the Color column.
SELECT P.ProductID, P.Name,P.Color, P.ListPrice
FROM Production.Product P
WHERE P.Color is NOT null;
GO
-- 5 : Now, combine two search arguments in the query you have been working with.
--You just want to see the rows that are not NULL for the column Color, and the column ListPricehas a value greater than zero.
SELECT P.ProductID, P.Name,P.Color, P.ListPrice
FROM Production.Product P
WHERE P.Color is NOT null
AND P.ListPrice > 0;
GO
-- 6 : Now we want a report that concatenates the columns Name and Color from the Production.Product table. 
--Your result set should look something like the following. Make sure you exclude rows that are NULL for the column Color. 
--Also notice the column name.
SELECT CONCAT(P.Name,' : ',P.Color) AS Name_And_Color
FROM Production.Product P
WHERE P.Color is NOT null;
GO
-- 7 : Customize the previous query so the answer looks like the following.
SELECT CONCAT('NAME: ',P.Name,' -- COLOR: ',P.Color) AS Name_And_Color
FROM Production.Product P
WHERE P.Color is NOT null;
GO
-- 8 : Now we would like to see the columns ProductID and Name from the Production.Product table filtered by ProductID from 400 to 500.
SELECT P.ProductID,P.Name
FROM Production.Product P
WHERE P.ProductID BETWEEN 400 AND 500;
GO
-- 9 : We would like to see the columns ProductID, Name and color from the Production.Product table restricted to the colors black and blue.
SELECT P.ProductID, P.Name, P.Color
FROM Production.Product P
WHERE P.Color IN ('black', 'blue');
GO
-- 10 : To begin with, we would like a report on products that begins with the letter S.
--Write a query that retrieves the columns Name and ListPrice from the Production.Product table. 
--Your result set should look something like the following. Order the result set by the Name column
SELECT P.Name, P.ListPrice
FROM Production.Product P
WHERE P.Name LIKE 'S%'
ORDER BY P.Name;
GO
-- 11 : Now we would like a report on products that begins with the letters S or A. 
--Write a query that retrieves the columns Name and ListPrice from the Production.Product table. 
--Your result set should look something like the following. Order the result set by the Name column.
SELECT P.Name, P.ListPrice
FROM Production.Product P
WHERE P.Name LIKE 'S%'
OR P.Name LIKE 'A%'
ORDER BY P.Name;
GO
--12 : Adjust your query so you retrieve rows that have a Name that begins with the letters SPO, 
--but is then not followed by the letter K. After this zero or more letters can exists. Order the result set by the Name column
SELECT P.Name, P.ListPrice
FROM Production.Product P
WHERE P.Name LIKE 'SPO%'
AND P.Name NOT LIKE 'SPOK%'
ORDER BY P.Name;
GO
-- 13 : Write a query that retrieves unique colors from the table Production.Product. We do not want to see all the rows, 
--just what colors that exist in the column Color.
SELECT distinct(P.Color)
FROM Production.Product P
GO
--14 : Write a query that retrieves the unique combination of columns ProductSubcategoryID and Color from the Production.Product table.
--Format and sort so the result set accordingly to the following. We do not want any rows that are NULL.in any of the two columns in the result.
SELECT DISTINCT P.ProductSubcategoryID, P.Color
FROM Production.Product P
WHERE P.ProductSubcategoryID IS NOT NULL
AND P.Color IS NOT NULL;
GO
--15 : We do not want any Red or Black products from any SubCategory than those with the value of 1 in column ProductSubCategoryID, 
--unless they cost between 1000 and 2000.
SELECT ProductSubCategoryID
      , LEFT([Name],35) AS [Name]
      , Color, ListPrice
FROM Production.Product
WHERE (Color IN ('Red','Black') AND ProductSubCategoryID = 1)
OR ListPrice BETWEEN 1000 AND 2000;
GO
--16: Use the Production.Product table to return product name, color and list price for each product. 
--For the color column, where there is NULL, replace it with the string Unknown.
SELECT Name, COALESCE(Color,'Unknown') AS Color, ListPrice
FROM Production.Product;
GO
-- Exercise 2: Grouping and Summarizing Data
--1 : How many products can you find in the Production.Product table?
SELECT COUNT (Name)
FROM Production.Product;
GO
-- 2: Write a query that retrieves the number of products in the Production.Product table that are included in a subcategory. 
--The rows that have NULL in column ProductSubcategoryID are considered to not be a part of any subcategory.
SELECT COUNT (ProductSubcategoryID) AS HasSubCategoryID
FROM Production.Product
WHERE ProductSubcategoryID IS NOT NULL;
GO
-- 3 : How many Products reside in each SubCategory?
SELECT ProductSubcategoryID, COUNT (COALESCE (ProductSubcategoryID, '-99')) AS CountedProducts
FROM Production.Product
GROUP BY ProductSubcategoryID;
GO
-- SỬ DỤNG COUNT (*)
SELECT ProductSubcategoryID, COUNT (*) AS CountedProducts
FROM Production.Product
GROUP BY ProductSubcategoryID;
GO
--4 : Try to write two different queries to find out how many products that do not have a product subcategory. 
--One query without the WHERE clause and one query using a WHERE clause. 
--The rows that have NULL in column ProductSubcategoryID are considered to not be a part of any subcategory.

-- One query without the WHERE clause.
SELECT top 1 COUNT (COALESCE (ProductSubcategoryID, '-99')) AS NoSubCat
FROM Production.Product
GROUP BY ProductSubcategoryID;
go
-- The other way using a WHERE clause.
SELECT COUNT (*) AS NoSubCat
FROM Production.Product
WHERE ProductSubcategoryID IS NULL;
GO
-- 5 : 	A report is needed, the summary of products in stock. Write a query against another table this time, the Production.ProductInventory table.
SELECT P.ProductID, SUM (I.Quantity) as TheSum
FROM Production.Product P, Production.ProductInventory I
WHERE P.ProductID = I.ProductID
GROUP BY P.ProductID;
GO
-- 6 : Continue to write on the query in previous exercise. Add a WHERE clause that extracts the rows that have 
--the column LocationID set to 40 and limit the result to include just summarized quantities less then 100.
SELECT P.ProductID, SUM (I.Quantity) as TheSum
FROM Production.Product P, Production.ProductInventory I
WHERE P.ProductID = I.ProductID
AND I.LocationID = 40
GROUP BY P.ProductID
HAVING SUM (I.Quantity) < 100;
GO
-- 7 : In this query we also want to see what shelf the product is to be delivered from. Add code to the previous query.
SELECT I.Shelf, P.ProductID, SUM (I.Quantity) as TheSum
FROM Production.Product P, Production.ProductInventory I
WHERE P.ProductID = I.ProductID
AND I.LocationID = 40
GROUP BY P.ProductID, I.Shelf
HAVING SUM (I.Quantity) < 100;
GO
-- 8 : We would like to see the average quantity for products where column LocationID has the value of 10. 
--The table Production.ProductInventory has the answer.
SELECT  AVG (I.Quantity) as TheAvg
FROM Production.ProductInventory I
WHERE I.LocationID = 10;
GO
-- 9 : To continue to write on the previous query, we would like to see the result by shelf excluding rows that has the value of N/A 
--in the column Shelf. We also want to see a total average based on shelf only and also for all products (“grand total”).
SELECT I.ProductID, I.Shelf
      , AVG(I.Quantity) AS TheAvg
FROM Production.ProductInventory I
WHERE I.LocationID = 10 AND I.Shelf <> 'N/A'
GROUP BY GROUPING SETS ((I.Shelf),(I.Shelf,I.ProductID),())
ORDER BY I.Shelf;
GO
-- 10 : We want to know number of members (rows) and average list price in the Production.Product table. 
--This should be grouped independently over the Color and the Class column. We are not interested in any rows 
--where Color nor Class are null (WHERE Class IS NOT NULL AND Color IS NOT NULL).
SELECT Color, Class, COUNT(Class) AS TheCount
      , AVG(ListPrice) AS TheAvg
FROM Production.Product
WHERE Class IS NOT NULL AND Color IS NOT NULL
GROUP BY GROUPING SETS ((Class),(Color))
ORDER BY Color;
GO
--another way:
SELECT Color,Null, COUNT(Class) AS TheCount
      , AVG(ListPrice) AS TheAvg
FROM Production.Product
WHERE Class IS NOT NULL AND Color IS NOT NULL
GROUP BY Color
UNION ALL
SELECT Null,Class, COUNT(Class) AS TheCount
      , AVG(ListPrice) AS TheAvg
FROM Production.Product
WHERE Class IS NOT NULL AND Color IS NOT NULL
GROUP BY Class
ORDER BY Color;
-- 11 : We now want to examine the function GROUPING. The following query generates the result below the query itself. 
--Take a look and complete the query so it results to the second result set.
-- ĐỀ : 
SELECT ProductSubcategoryID
      , COUNT(Name) as Counted
FROM Production.Product
GROUP BY ROLLUP (ProductSubcategoryID);
GO
-- way-one :
SELECT ProductSubcategoryID
      , COUNT(Name) as Counted,
	  coalesce (REPLACE(ProductSubcategoryID,ProductSubcategoryID, 0),1) AS IsGrandTotal
FROM Production.Product
GROUP BY ROLLUP (ProductSubcategoryID)
ORDER BY ProductSubcategoryID,COUNT(Name);
GO
--way-two:
    SELECT ProductSubcategoryID
      , COUNT(Name) as Counted
      , GROUPING(ProductSubcategoryID) AS  -- GROUPING : DATA KHI GỘP VÔ MỚI NULL THÌ 1, CHƯA GỘP MÀ DATA NULL SẴNG THÌ 0                
             IsGrandTotal
FROM Production.Product
GROUP BY ROLLUP (ProductSubcategoryID)
ORDER BY ProductSubcategoryID

