﻿CREATE DATABASE EMPLOYEE_MANAGEMENT_SYSTEM;
GO
USE EMPLOYEE_MANAGEMENT_SYSTEM;

/* Q1.1
Create an EMPLOYEE table with the most appropriate/economic field/column constraints & types. All fields are mandatory except Note field.
*/
GO
CREATE TABLE EMPLOYEE
(
	EmpNo char(6) NOT NULL PRIMARY KEY,
	EmpName nvarchar(50) NOT NULL,
	BirthDay date NOT NULL,
	DeptNo int NOT NULL,
	MgrNo char(5) NOT NULL,
	StartDate date NOT NULL,
	Salary money NOT NULL,
	Level tinyint NOT NULL check (level >= 1 and level <=7),
	Status tinyint NOT NULL,
	Note ntext
);

/* Q1.2
Create a SKILL table with the most appropriate/economic field/column constraints & types, all fields are mandatory except Note field.
*/
GO
CREATE TABLE SKILL
(
	SkillNo int NOT NULL PRIMARY KEY IDENTITY(1,1),
	SkillName varchar(50) NOT NULL,
	Note ntext
);
/* Q1.3
Create a DEPARTMENT table with the most appropriate/economic field/column constraints & types, all fields are mandatory except Note field.
*/
GO
CREATE TABLE DEPARTMENT
(
	DeptNo int NOT NULL PRIMARY KEY IDENTITY (1,1),
	DeptName nvarchar(50) NOT NULL,
	Note ntext
);
/* Q1.4
Create EMP_SKILL table with the most appropriate/economic field/column constraints & types, all fields are mandatory except Description field.
*/
GO
CREATE TABLE EMP_SKILL
(
	SkillNo int NOT NULL FOREIGN KEY REFERENCES  SKILL(SkillNo),
	EmpNo char(6) NOT NULL FOREIGN KEY REFERENCES EMPLOYEE(EmpNo),
	SkillLevel tinyint NOT NULL CHECK (SkillLevel >= 1 and SkillLevel <=3),
	RegDate date NOT NULL,
	Description ntext,
	CONSTRAINT EMP_PK PRIMARY KEY (SkillNo, EmpNo)
);
/* Q2.1
Add an Email field to EMPLOYEE table and make sure that the database will not allow the value for Email to be inserted into a new row if that value has already been used in another row.
*/
GO
ALTER TABLE EMPLOYEE
	ADD Email varchar(50) NOT NULL UNIQUE;
/* Q2.2
Modify EMPLOYEE table to set default values to 0 of MgrNo and Status fields.
*/
GO
ALTER TABLE EMPLOYEE
	ADD CONSTRAINT df_MgrNo DEFAULT 0 FOR MgrNo;
ALTER TABLE EMPLOYEE
	ADD CONSTRAINT df_Status DEFAULT 0 FOR Status;
/* Q3.1
Add the FOREIGN KEY constrain of DeptNo field to the EMPLOYEE table that will relate the DEPARTMENT table.
*/
GO
ALTER TABLE EMPLOYEE
	ADD CONSTRAINT fk_EMPLOYEE_DeptNo_DEPARTMENT
		FOREIGN KEY (DeptNo) REFERENCES DEPARTMENT(DeptNo);
/* Q3.2
Remove the Description field from the EMP_SKILL table.
*/
ALTER TABLE EMP_SKILL
	DROP COLUMN Description;
GO
/* Q4.1
Add at least 5 records into each of the created tables.
*/
INSERT INTO SKILL
	VALUES	('english','nghe noi doc viet duoc'),
			('japanese','nghe noi doc viet duoc'),
			('korean','nghe noi doc viet duoc'),
			('chinese','nghe noi doc viet duoc'),
			('vietnamese','nghe noi doc viet duoc');
GO
INSERT INTO DEPARTMENT
	VALUES	('kinh doanh','thuc hien ke hoach kinh doanh'),
			('ky thuat','thuc hien nhiem vu ky thuat'),
			('ke toan','thuc hien nhiem vu ke toan'),
			('cham soc khach hang','thuc hien nhiem vu cham soc khach hang'),
			('marketing','thuc hien ke hoach marketing');
GO
INSERT INTO EMPLOYEE
	VALUES	('EMP001','Phan Van Ngan','1990-12-12',1,'mg001','2020-01-01',3000000,4,0,'đang thử việc','ngan@fsoft.com.vn'),
			('EMP002','Trinh Quang Sang','1991-11-12',2,'mg002','2019-01-01',2000000,3,1,'đang làm việc','sang@fsoft.com.vn'),
			('EMP003','Le Van Dinh','1992-10-12',3,'mg003','2018-01-01',4000000,5,0,'đang đề xuất lên quản lý','dinh@fsoft.com.vn'),
			('EMP004','Nguyen Thi Tuyen','1993-09-12',4,'mg004','2020-01-01',5000000,3,2,'đang thử việc','tuyen@fsoft.com.vn'),
			('EMP005','Ha Tong Quyen','1994-08-12',5,'mg005','2017-01-01',6000000,4,0,'đang làm việc','quyen@fsoft.com.vn');
GO
INSERT INTO EMP_SKILL
	VALUES	(1,'EMP001',2,'2021-12-01'),
			(2,'EMP002',3,'2021-12-02'),
			(3,'EMP003',1,'2021-12-03'),
			(4,'EMP004',2,'2021-12-04'),
			(5,'EMP005',1,'2021-12-05');
GO
/* Q4.2
Create a VIEW called EMPLOYEE_TRACKING that will appear to the user as EmpNo, Emp_Name and Level. It has Level satisfied the criteria: Level >=3 and Level <= 5.
*/
CREATE VIEW EMPLOYEE_TRACKING AS
	SELECT EmpNo, EmpName, Level
		FROM EMPLOYEE
			WHERE Level >= 3 and Level <=5;
GO
SELECT * FROM EMPLOYEE_TRACKING;
GO