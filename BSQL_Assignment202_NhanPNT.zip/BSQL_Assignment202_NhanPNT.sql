﻿CREATE DATABASE Fresher_Training_Management;
USE Fresher_Training_Management;
GO
/* 1)
Create the tables (with the most appropriate/economic field/column constraints & types) and add at least 10 records into each created table.
*/
CREATE TABLE TRAINEE
(
	TraineeID int NOT NULL IDENTITY(1,1),
	Full_Name nvarchar(50) NOT NULL,
	Birth_Date date NOT NULL,
	Gender varchar(6) NOT NULL,
	ET_IQ tinyint NOT NULL CHECK (ET_IQ >= 0 and ET_IQ <=20),
	ET_Gmath tinyint NOT NULL CHECK (ET_Gmath >= 0 and ET_Gmath <=20),
	ET_English tinyint NOT NULL CHECK (ET_English >= 0 and ET_English <=50),
	Training_Class char(5) NOT NULL,
	Evaluation_Notes ntext
);
GO
INSERT INTO TRAINEE VALUES
('Do Thi Phuong Anh','2000-1-3','Female',20,20,50,'TC001','cute girl'),
('Nguyen Lan anh','2000-2-4','Female',20,20,50,'TC002','lovely girl'),
('Nguyen Tien anh','2000-3-5','Male',20,20,50,'TC003','good boy'),
('Giap Thi Ngoc Anh','2000-4-6','Female',20,20,50,'TC001','lovely girl'),
('Tran Thi Linh Chi','2000-5-7','Female',20,20,50,'TC002','nice girl'),
('Le Quoc Dai','2000-6-8','Male',20,20,50,'TC003','bad boy'),
('Pham Van Dien','2000-7-9','Male',20,20,50,'TC001','cute boy'),
('Nguyen A Dong','2000-8-10','Male',20,20,50,'TC002','handsome boy'),
('Le Thuy Dung','2000-9-11','Female',20,20,50,'TC003','good girl'),
('Nguyen Tung Duong','2000-10-12','Male',20,20,50,'TC001','black-skin boy'),
('Nguyen Thi Me Ghi','2000-1-3','Female',20,10,50,'TC001','cute girl'),
('Do Thi Thanh Ha','2003-2-4','Female',16,12,40,'TC002','lovely girl'),
('Luong Dinh Ha','2000-3-5','Male',12,14,30,'TC003','good boy'),
('Ta Thu Ha','2001-6-6','Female',10,16,20,'TC001','lovely girl'),
('Ly Van Hanh','2002-5-7','Male',8,10,18,'TC002','nice girl'),
('Nguyen Thu Hien','2003-2-8','Female',6,9,16,'TC003','bad boy'),
('Nham Ngoc Hieu','2000-3-9','Male',10,18,25,'TC001','cute boy'),
('Bui Minh Hoang','2001-1-10','Male',9,17,35,'TC002','handsome boy'),
('Do Thi Hue','2002-5-11','Female',17,15,19,'TC003','good girl'),
('Ta Duy Hung','2003-1-12','Male',19,20,45,'TC001','black-skin boy');
GO
/* 2)
Change the table TRAINEE to add one more field named Fsoft_Account which is a not-null & unique field.
*/
TRUNCATE TABLE TRAINEE;
GO
ALTER TABLE TRAINEE
	ADD Fsoft_Account varchar(20) NOT NULL UNIQUE;
GO
INSERT INTO TRAINEE VALUES
('Do Thi Phuong Anh','2000-1-3','Female',20,10,50,'TC001','cute girl','Anhdtp'),
('Nguyen Lan anh','2003-2-4','Female',16,12,40,'TC002','lovely girl','Anhnl'),
('Nguyen Tien anh','2000-6-5','Male',12,14,30,'TC003','good boy','Anhnt'),
('Giap Thi Ngoc Anh','2001-4-6','Female',10,16,20,'TC001','lovely girl','Anhgtn'),
('Tran Thi Linh Chi','2002-5-7','Female',8,10,28,'TC002','nice girl','Chittl'),
('Le Quoc Dai','2003-2-8','Male',9,11,2,'TC003','bad boy','Dailq'),
('Pham Van Dien','2000-2-9','Male',4,18,25,'TC001','cute boy','Dienpv'),
('Nguyen A Dong','2001-1-10','Male',12,17,35,'TC002','handsome boy','Dongna'),
('Le Thuy Dung','2002-5-11','Female',17,15,15,'TC003','good girl','Dunglt'),
('Nguyen Tung Duong','2003-4-12','Male',19,20,45,'TC001','black-skin boy','Duongnt'),
('Nguyen Thi Me Ghi','2000-1-3','Female',20,10,50,'TC001','cute girl','Ghintm'),
('Do Thi Thanh Ha','2003-2-4','Female',16,12,40,'TC002','lovely girl','Hadth'),
('Luong Dinh Ha','2000-3-5','Male',12,14,30,'TC003','good boy','Hald'),
('Ta Thu Ha','2001-6-6','Female',10,16,20,'TC001','lovely girl','Hath'),
('Ly Van Hanh','2002-5-7','Male',8,10,18,'TC002','nice girl','Hanhlv'),
('Nguyen Thu Hien','2003-2-8','Female',6,9,16,'TC003','bad boy','Hiennt'),
('Nham Ngoc Hieu','2000-3-9','Male',10,18,25,'TC001','cute boy','Hieunn'),
('Bui Minh Hoang','2001-1-10','Male',9,17,35,'TC002','handsome boy','Hoangbm'),
('Do Thi Hue','2002-5-11','Female',17,15,19,'TC003','good girl','Huedt'),
('Ta Duy Hung','2003-1-12','Male',19,20,45,'TC001','black-skin boy','Hungtd');
GO
/* 3)
Create a VIEW that includes all the ET-passed trainees. One trainee is considered as ET-passed when he/she has the entry test points satisfied below criteria:
ET_IQ + ET_Gmath >=20
ET_IQ>=8
ET_Gmath>=8
ET_English>=18​
*/
CREATE VIEW ET_PASSED_TRAINEE AS
	SELECT * FROM TRAINEE WHERE
		ET_IQ + ET_Gmath >=20 AND
		ET_IQ>=8 AND
		ET_Gmath>=8 AND
		ET_English>=18;
GO
/* 4)
Query all the trainees who are passed the entry test, group them into different birth months.
*/
SELECT *, Month(Birth_Date) AS Group_Into_Different_Birth_Month FROM ET_PASSED_TRAINEE ORDER BY Group_Into_Different_Birth_Month;
GO
/* 5)
Query the trainee who has the longest name, showing his/her age along with his/her basic information (as defined in the table).
*/
CREATE VIEW VIEW_TRAINEE AS
SELECT *, len(Full_Name) AS Length_Name, year(GETDATE()) - year(Birth_Date) AS Age FROM TRAINEE;
GO
SELECT * FROM VIEW_TRAINEE WHERE Length_Name = (SELECT max(Length_Name) FROM VIEW_TRAINEE);
GO
