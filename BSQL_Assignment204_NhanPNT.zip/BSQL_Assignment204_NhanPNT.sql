CREATE DATABASE Movie_Collection;
USE Movie_Collection;
GO
--Q1.1:
CREATE TABLE MOVIE
(
	Movie_Name varchar(200) NOT NULL PRIMARY KEY,
	Duration smallint NOT NULL CHECK (Duration >= 60),
	Genre tinyint NOT NULL CHECK (Genre >=1 and Genre <=8),
	Director varchar(50) NOT NULL,
	Turnover bigint NOT NULL,
	Comment ntext
);
GO
--Q1.2:
CREATE TABLE ACTOR
(
	Actor_Name varchar(50) NOT NULL PRIMARY KEY,
	Age tinyint NOT NULL,
	Average_Movie_Salary int NOT NULL,
	Nationality varchar(50) NOT NULL
);
GO
--Q1.3:
CREATE TABLE ACTEDLN
(
	Movie_Name varchar(200) NOT NULL FOREIGN KEY REFERENCES MOVIE(Movie_Name),
	Actor_Name varchar(50) NOT NULL FOREIGN KEY REFERENCES ACTOR(Actor_Name),
	CONSTRAINT PK_ACTEDLN PRIMARY KEY (Movie_Name,Actor_Name)
);
GO
--Q2.1:
ALTER TABLE MOVIE
	ADD Image_Link varchar(200) NOT NULL UNIQUE;
GO
--Q2.2:
INSERT INTO MOVIE VALUES
('Citizen Kane',60,1,'Orson Welles',1000000,'good','film.com/film1'),
('Casablanca',70,2,'Michael Curtiz',2000000,'excelent','film.com/film2'),
('The Godfather',80,3,'Francis Ford Coppola',3000000,'bad','film.com/film3'),
('Gone with the Wind',90,4,'Victor Fleming',4000000,'not bad','film.com/film4'),
('Lawrence of Arabia',100,5,'David Lean',5000000,'not good','film.com/film5'),
('The Wizard of Oz',110,6,'Victor Fleming',6000000,'ok','film.com/film6'),
('The Graduate',120,7,'Mike Nichols',7000000,'not ok','film.com/film7'),
('On the Waterfront',130,8,'Elia Kazan',8000000,'not excelent','film.com/film8'),
('Schindler  List',140,1,'Steven Spielberg',9000000,'good','film.com/film9'),
('Singing in the Rain',150,2,'Gene Kelly',10000000,'excelent','film.com/film10'),
('It is a Wonderful Life',160,3,'Frank Capra',11000000,'bad','film.com/film11'),
('Sunset Boulevard',170,4,'Billy Wilder',12000000,'not bad','film.com/film12'),
('The Bridge on the River Kwai',180,5,'David Lean',13000000,'not good','film.com/film13'),
('Some Like It Hot',190,6,'Billy Wilder',14000000,'ok','film.com/film14'),
('Star Wars',200,7,'George Lucas',15000000,'not ok','film.com/film15'),
('All About Eve',210,8,'Joseph L. Mankiewicz',16000000,'not excelent','film.com/film16'),
('The African Queen',220,5,'John Huston',17000000,'good','film.com/film17'),
('Psycho',230,6,'Alfred Hitchcock',18000000,'excelent','film.com/film18'),
('Chinatown',240,7,'Roman Polanski',19000000,'bad','film.com/film19'),
('One Flew Over the Cuckoo is Nest',250,8,'Alfred George',20000000,'not bad','film.com/film20');
GO
INSERT INTO ACTOR VALUES
('Daquan Wise',45,100000,'USA'),
('Lance Foley',46,120000,'UK'),
('Graiden Smith',47,140000,'USA'),
('Bernard Parker',48,160000,'UK'),
('Fuller Jefferson',49,180000,'USA'),
('Hall Phelps',50,200000,'UK'),
('Troy Flowers',51,220000,'USA'),
('Ulysses Woodard',52,240000,'UK'),
('Sebastian Cooley',53,260000,'USA'),
('Orlando Tillman',54,280000,'UK'),
('Ethan Gill',55,300000,'USA'),
('Reuben Walton',56,320000,'UK'),
('Alvin Everett',57,340000,'USA'),
('Harlan Guerrero',58,360000,'UK'),
('Wylie Roth',59,380000,'USA'),
('Michael Huber',60,400000,'UK'),
('Melvin Wheeler',61,420000,'USA'),
('Kaseem Cobb',62,440000,'UK'),
('Hyatt Swanson',63,460000,'USA'),
('Barrett Wagner',64,480000,'UK')
;
GO
INSERT INTO ACTEDLN VALUES
('Casablanca','Harlan Guerrero'),
('Casablanca','Troy Flowers'),
('Casablanca','Reuben Walton'),
('Casablanca','Melvin Wheeler'),
('Casablanca','Daquan Wise'),
('Citizen Kane','Troy Flowers'),
('Citizen Kane','Ethan Gill'),
('Citizen Kane','Michael Huber'),
('Gone with the Wind','Troy Flowers'),
('Gone with the Wind','Sebastian Cooley'),
('Gone with the Wind','Harlan Guerrero'),
('Gone with the Wind','Melvin Wheeler'),
('Lawrence of Arabia','Troy Flowers'),
('Lawrence of Arabia','Orlando Tillman'),
('Lawrence of Arabia','Wylie Roth'),
('Lawrence of Arabia','Melvin Wheeler'),
('Lawrence of Arabia','Graiden Smith'),
('The Godfather','Reuben Walton'),
('The Godfather','Troy Flowers'),
('The Godfather','Kaseem Cobb');
GO
--Q3.1:
SELECT * FROM ACTOR WHERE Age > 50;
--Q3.2:
SELECT Actor_Name, Average_Movie_Salary
	FROM ACTOR
		ORDER BY Average_Movie_Salary desc;
GO
--Q3.3:
SELECT * FROM ACTEDLN WHERE Actor_Name = 'Troy Flowers';
GO
--Q3.4:
SELECT Movie_Name, COUNT(Movie_Name) AS Amount_Of_Actor FROM ACTEDLN GROUP BY Movie_Name;
GO