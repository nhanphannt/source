CREATE DATABASE DMS
USE [DMS]
GO
/****** Object:  Table [dbo].[EMPMAJOR]    Script Date: 06/01/2015 17:22:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[EMPMAJOR](
	[emp_no] [char](6) NOT NULL,
	[major] [char](3) NOT NULL,
	[major_name] [varchar](50) NOT NULL,
 CONSTRAINT [PK_Major] PRIMARY KEY CLUSTERED 
(
	[emp_no] ASC,
	[major] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[EMP]    Script Date: 06/01/2015 17:22:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[EMP](
	[emp_no] [char](6) NOT NULL,
	[last_name] [varchar](50) NOT NULL,
	[first_name] [varchar](50) NOT NULL,
	[dept_no] [char](3) NOT NULL,
	[job] [varchar](50) NULL,
	[salary] [money] NOT NULL,
	[bonus] [money] NULL,
	[ed_level] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[emp_no] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[DEPT]    Script Date: 06/01/2015 17:22:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[DEPT](
	[dept_no] [char](3) NOT NULL,
	[dept_name] [varchar](50) NOT NULL,
	[mgn_no] [char](6) NULL,
	[admr_dept] [char](3) NOT NULL,
	[location] [varchar](100) NULL,
PRIMARY KEY CLUSTERED 
(
	[dept_no] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[dept_name] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[EMPPROJACT]    Script Date: 06/01/2015 17:22:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[EMPPROJACT](
	[emp_no] [char](6) NOT NULL,
	[proj_no] [char](6) NOT NULL,
	[act_no] [int] NOT NULL,
 CONSTRAINT [PK_EPA] PRIMARY KEY CLUSTERED 
(
	[emp_no] ASC,
	[proj_no] ASC,
	[act_no] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[ACT]    Script Date: 06/01/2015 17:22:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ACT](
	[act_no] [int] NOT NULL,
	[act_des] [varchar](50) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[act_no] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  ForeignKey [FK_Dept]    Script Date: 06/01/2015 17:22:33 ******/
ALTER TABLE [dbo].[DEPT]  WITH CHECK ADD  CONSTRAINT [FK_Dept] FOREIGN KEY([mgn_no])
REFERENCES [dbo].[EMP] ([emp_no])
GO
ALTER TABLE [dbo].[DEPT] CHECK CONSTRAINT [FK_Dept]
GO
/****** Object:  ForeignKey [FK__EMP__dept_no__3E52440B]    Script Date: 06/01/2015 17:22:33 ******/
ALTER TABLE [dbo].[EMP]  WITH CHECK ADD FOREIGN KEY([dept_no])
REFERENCES [dbo].[DEPT] ([dept_no])
ON DELETE CASCADE
GO
/****** Object:  ForeignKey [FK_Major]    Script Date: 06/01/2015 17:22:33 ******/
ALTER TABLE [dbo].[EMPMAJOR]  WITH CHECK ADD  CONSTRAINT [FK_Major] FOREIGN KEY([emp_no])
REFERENCES [dbo].[EMP] ([emp_no])
GO
ALTER TABLE [dbo].[EMPMAJOR] CHECK CONSTRAINT [FK_Major]
GO
/****** Object:  ForeignKey [FK_EPA1]    Script Date: 06/01/2015 17:22:33 ******/
ALTER TABLE [dbo].[EMPPROJACT]  WITH CHECK ADD  CONSTRAINT [FK_EPA1] FOREIGN KEY([emp_no])
REFERENCES [dbo].[EMP] ([emp_no])
GO
ALTER TABLE [dbo].[EMPPROJACT] CHECK CONSTRAINT [FK_EPA1]
GO
/****** Object:  ForeignKey [FK_EPA2]    Script Date: 06/01/2015 17:22:33 ******/
ALTER TABLE [dbo].[EMPPROJACT]  WITH CHECK ADD  CONSTRAINT [FK_EPA2] FOREIGN KEY([act_no])
REFERENCES [dbo].[ACT] ([act_no])
GO
ALTER TABLE [dbo].[EMPPROJACT] CHECK CONSTRAINT [FK_EPA2]
GO

INSERT INTO ACT(act_no,act_des) VALUES
('90','activity 90'),
('91','activity 91'),
('92','activity 92'),
('93','activity 93'),
('94','activity 94'),
('95','activity 95'),
('96','activity 96'),
('97','activity 97'),
('98','activity 98'),
('99','activity 99'),
('100','activity 100'),
('101','activity 101'),
('102','activity 102'),
('103','activity 103'),
('104','activity 104'),
('105','activity 105'),
('106','activity 106'),
('107','activity 107'),
('108','activity 108'),
('109','activity 109')

GO
INSERT INTO DEPT(dept_no,dept_name,admr_dept,location) VALUES
('D01','SPIFFY COMPUTER SERVICE DIV','A01','Vienna'),
('D02','PLANNING','A02','Gelderland'),
('D03','INFORMATION CENTER','A03','Pue'),
('D04','DEVELOPMENT CENTER','A04','Vermont'),
('D05','MANUFACTURING SYSTEMS','A05','Gye'),
('D06','ADMINISTRATION SYSTEMS','A06','Ayd'),
('D07','SUPPORT SERVICES','A07','Uttar Pradesh'),
('D08','OPERATIONS','A08','Antioquia'),
('D09','SOFTWARE SUPPORT','A09','Cantabria'),
('D10','BRANCH OFFICE F2','A10','Ontario'),
('D11','BRANCH OFFICE G2','A11','Hidalgo'),
('D12','BRANCH OFFICE H2','A12','Punjab'),
('D13','BRANCH OFFICE I2','A13','Sinaloa'),
('D14','BRANCH OFFICE J2','A14','Lanarkshire'),
('D15','BRANCH OFFICE I3','A15','Arequipa'),
('D16','BRANCH OFFICE J3','A16','North Island'),
('D17','BRANCH OFFICE I4','A17','Maule'),
('D18','BRANCH OFFICE J4','A18','Angus'),
('D19','BRANCH OFFICE I5','A19','Queensland'),
('D20','BRANCH OFFICE J5','A20','Veneto')
GO
INSERT INTO EMP(emp_no,last_name,first_name,dept_no,job,salary,bonus,ed_level) VALUES
('EMP001','George','Oneill','D01','Dentist',27600,2760,1),
('EMP002','Brian','Randall','D06','Registered Nurse',712900,71290,2),
('EMP003','Peter','Rosa','D11','Pharmacist',69740,6974,3),
('EMP004','George','Mcmillan','D16','Computer Systems Analyst',120440,12044,4),
('EMP005','Ursula','Bowman','D01','Physician',168330,16833,5),
('EMP006','Irma','Willis','D06','Database Administrator',33600,3360,6),
('EMP007','Charity','Charles','D11','Software Developer',143400,14340,7),
('EMP008','Brooke','Bowers','D16','Physical Therapist',65740,6574,1),
('EMP009','Hedy','Underwood','D01','Web Developer',65740,6574,2),
('EMP010','Rebecca','Cline','D06','Dental Hygienist',68300,6830,3),
('EMP011','Karleigh','Hancock','D11','Occupational Therapist',36420,3642,4),
('EMP012','Brody','Stafford','D16','Veterinarian',23000,2300,5),
('EMP013','Zorita','Jensen','D01','Computer Programmer',43730,4373,6),
('EMP014','Portia','Pickett','D06','School Psychologist',31700,3170,7),
('EMP015','Kasimir','Keith','D11','Physical Therapist Assistant',30300,3030,1),
('EMP016','Xandra','Morrow','D16','Interpreter & Translator',24620,2462,2),
('EMP017','Brady','Ramsey','D01','Mechanical Engineer',21200,2120,3),
('EMP018','Jenna','Castillo','D06','Veterinary Technologist & Technician',41700,4170,4),
('EMP019','Aiko','Trevino','D11','Epidemiologist',37630,3763,5),
('EMP020','Chandler','Forbes','D16','IT Manager',55830,5583,6)
GO
UPDATE DEPT
SET mgn_no = 'EMP001'
WHERE Dept_no IN ('D02', 'D05', 'D09', 'D17')
GO
UPDATE DEPT
SET mgn_no = 'EMP002'
WHERE Dept_no IN ('D03')
GO
UPDATE DEPT
SET mgn_no = 'EMP006'
WHERE Dept_no IN ('D04','D10','D12','D14')
GO
UPDATE DEPT
SET mgn_no = 'EMP011'
WHERE Dept_no IN ('D17','D19')
GO
UPDATE DEPT
SET mgn_no = 'EMP016'
WHERE Dept_no IN ('D08','D16','D20')
GO
INSERT INTO EMPMAJOR(emp_no,major,major_name) VALUES
('EMP002','MAT','math'),
('EMP005','CSI','computer science'),
('EMP008','JS','Java Script'),
('EMP011','CSI','computer science'),
('EMP014','SQL','Structure Query Language'),
('EMP017','ENG','English'),
('EMP002','KOR','Korean'),
('EMP005','JP','Japanese'),
('EMP008','CN','Chinese'),
('EMP011','VN','Vietnamese'),
('EMP014','BA','Bussiness Administrator'),
('EMP017','ACT','Accountant'),
('EMP002','PY','Python'),
('EMP005','C','C++'),
('EMP008','CL','Cloud'),
('EMP011','MS','Music'),
('EMP014','PI','Piano'),
('EMP017','GT','Ghitar'),
('EMP002','ACT','Actor'),
('EMP005','PTS','Photoshop')
GO
INSERT INTO EMPPROJACT(emp_no,proj_no,act_no) VALUES
('EMP001','PJ01',90),
('EMP006','PJ02',91),
('EMP011','PJ03',92),
('EMP016','PJ04',93),
('EMP001','PJ05',94),
('EMP006','PJ06',95),
('EMP011','PJ07',96),
('EMP016','PJ08',97),
('EMP001','PJ09',98),
('EMP006','PJ10',99),
('EMP011','PJ11',100),
('EMP016','PJ12',101),
('EMP001','PJ13',102),
('EMP006','PJ14',103),
('EMP011','PJ15',104),
('EMP016','PJ16',105),
('EMP001','PJ17',106),
('EMP006','PJ18',107),
('EMP011','PJ19',108),
('EMP016','PJ20',109)
GO
--304.2 Find employees who are currently working on a project or projects. Employees working on projects will have a row(s) on the EMPPROJACT table.
SELECT	CONCAT(E.first_name ,' ', E.last_name) AS Full_Name,
		COUNT(EP.proj_no) AS Amount_Project
FROM EMP AS E
	JOIN EMPPROJACT AS EP
	ON E.emp_no = EP.emp_no
GROUP BY E.first_name, E.last_name
ORDER BY COUNT(EP.proj_no)
GO
--304.3. Find all employees who major in math (MAT) and computer science (CSI)
SELECT	CONCAT(E.first_name ,' ', E.last_name) AS Full_Name,
		EM.major,
		EM.major_name
FROM EMP AS E
	JOIN EMPMAJOR AS EM
	ON E.emp_no = EM.emp_no
WHERE EM.major IN ('MAT','CSI')
GO
--304.4. Find employees who work on all activities between 90 and 110
SELECT	CONCAT(E.first_name ,' ', E.last_name) AS Full_Name,
		A.act_no,
		A.act_des
FROM EMP AS E
	JOIN EMPPROJACT AS EP ON E.emp_no = EP.emp_no
	JOIN ACT AS A ON EP.act_no = A.act_no
WHERE A.act_no BETWEEN 90 AND 110
--304.5 Provide a report of employees with employee detail information along with department aggregate information. Give >=2 solutions (Scalar Fullselect, Join, CTE, ect).
--way-1: use JOIN
SELECT E.emp_no, E.last_name, E.first_name, E.salary, E.dept_no, E2.DEPT_AVG_SAL
FROM EMP E
	JOIN (SELECT dept_no, ROUND(AVG(salary),2) AS DEPT_AVG_SAL FROM EMP GROUP BY dept_no) AS E2
	ON E.dept_no = E2.dept_no
GROUP BY E.emp_no, E.last_name, E.first_name, E.salary, E.dept_no, E2.DEPT_AVG_SAL
--way-2: use temporary-table
SELECT dept_no, ROUND(AVG(salary),2) AS DEPT_AVG_SAL INTO #Temp_Dept
FROM EMP GROUP BY dept_no

SELECT E.emp_no, E.last_name, E.first_name, E.salary, E2.dept_no, E2.DEPT_AVG_SAL
FROM EMP E
	JOIN #Temp_Dept AS E2
	ON E.dept_no = E2.dept_no
GROUP BY E.emp_no, E.last_name, E.first_name, E.salary, E2.dept_no, E2.DEPT_AVG_SAL
ORDER BY E2.dept_no
--way-3: use VIEW
CREATE VIEW View_Dept AS
SELECT dept_no, ROUND(AVG(salary),2) AS DEPT_AVG_SAL
FROM EMP GROUP BY dept_no

SELECT E.emp_no, E.last_name, E.first_name, E.salary, E2.dept_no, E2.DEPT_AVG_SAL
FROM EMP E
	JOIN View_Dept AS E2
	ON E.dept_no = E2.dept_no
GROUP BY E.emp_no, E.last_name, E.first_name, E.salary, E2.dept_no, E2.DEPT_AVG_SAL

--304.6. Use CTE technique to provide a report of employees whose education levels are higher than the average education level of their respective department.
WITH CTE_AVERAGE_EDUCATION AS
(
	SELECT  D.dept_no, AVG(CAST(ed_level AS decimal)) AS AVERAGE_EDUCATION
	FROM EMP AS E JOIN DEPT AS D ON E.dept_no = D.dept_no
	GROUP BY D.dept_no
)
SELECT * FROM EMP AS E JOIN CTE_AVERAGE_EDUCATION ON E.dept_no = CTE_AVERAGE_EDUCATION.dept_no
WHERE E.ed_level > CTE_AVERAGE_EDUCATION.AVERAGE_EDUCATION

--304.7 Return the department number, department name and the total payroll for the department that has the highest payroll. Payroll will be defined as the sum of all salaries and bonuses for the department.
WITH CTE_PAYROLL AS
(
	SELECT TOP 1  D.dept_no, SUM(E.salary) + SUM(E.bonus) AS PAYROLL
	FROM EMP AS E JOIN DEPT AS D ON E.dept_no = D.dept_no
	GROUP BY D.dept_no
	ORDER BY PAYROLL DESC
)
SELECT D.dept_no, D.dept_name, CTE_PAYROLL.PAYROLL AS Highest_Payroll
FROM DEPT AS D JOIN CTE_PAYROLL ON D.dept_no = CTE_PAYROLL.dept_no
--304.8.1. Return the employees with the top 5 salaries. Could be 5 employees with different salaries.
SELECT TOP 5 * FROM EMP ORDER BY salary DESC
--304.8.2. Return the employees with the top 5 salaries. Could be many employees having the same salaries.
;WITH CTE_SALARY AS
(
	SELECT DENSE_RANK() OVER(ORDER BY E.salary DESC) AS Rating, E.first_name, E.last_name, E.salary 
	FROM EMP E
)
SELECT * FROM CTE_SALARY WHERE CTE_SALARY.Rating <= 5
GO