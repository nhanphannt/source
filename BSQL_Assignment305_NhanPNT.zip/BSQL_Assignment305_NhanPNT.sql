﻿USE AdventureWorks2008;
GO
--Exercise 1:
-- 1.1 :

SELECT P.Name
FROM Production.Product P
WHERE P.ProductSubcategoryID IN (
	SELECT G.ProductSubcategoryID
	FROM Production.ProductSubcategory G
	WHERE G.Name LIKE 'SaddleS' );

--1.2 : 

SELECT P.Name
FROM Production.Product P
WHERE P.ProductSubcategoryID IN (
	SELECT G.ProductSubcategoryID
	FROM Production.ProductSubcategory G
	WHERE G.Name LIKE 'Bo%' );

--1.3 :
	--way-one
SELECT P.Name
FROM Production.Product P
WHERE P.ListPrice = (
	SELECT MIN(P.ListPrice)
	FROM Production.Product P
	WHERE P.ProductSubcategoryID = 3)

	--way-two
SELECT T.Name FROM (
	SELECT TOP 1 WITH TIES P.Name , P.ListPrice, P.ProductSubcategoryID
	FROM Production.Product P
	GROUP BY P.Name , P.ListPrice, P.ProductSubcategoryID
	HAVING P.ProductSubcategoryID = 3
	ORDER BY P.ListPrice) AS T
--1.4 :

-- USE SUBQUERY

SELECT PC.Name
FROM Person.CountryRegion PC
WHERE PC.CountryRegionCode IN (
	SELECT PS.CountryRegionCode
	FROM Person.StateProvince PS
	GROUP BY PS.CountryRegionCode
	HAVING COUNT (PS.CountryRegionCode) < 10);
-- USE JOIN

SELECT PC.Name
FROM Person.CountryRegion PC
INNER JOIN (
	SELECT PS.CountryRegionCode
	FROM Person.StateProvince PS
	GROUP BY PS.CountryRegionCode
	HAVING COUNT (PS.CountryRegionCode) < 10) AS ASS
ON PC.CountryRegionCode = ASS.CountryRegionCode;

--1.5 : 

SELECT S.SalesPersonID, (SELECT AVG(SS.SubTotal) FROM Sales.SalesOrderHeader SS WHERE SS.SalesPersonID IS NOT NULL) -  AVG(S.SubTotal) AS SalesDiff
FROM Sales.SalesOrderHeader S
WHERE S.SalesPersonID IS NOT NULL
GROUP BY S.SalesPersonID;

--1.6: 

-- B1:

SELECT AVG(P.ListPrice)
FROM Production.Product P
WHERE P.ProductSubcategoryID IN (1,2,3);

-- B2:

SELECT P.Name,
p.ListPrice - (SELECT AVG(P.ListPrice) FROM Production.Product P WHERE P.ProductSubcategoryID IN (1,2,3)) as Diff
FROM Production.Product P
WHERE P.ProductSubcategoryID IN (1,2,3);

-- B3 :

; WITH CTE_X AS (
SELECT P.Name,-- P.ListPrice,
p.ListPrice - (SELECT AVG(P.ListPrice) FROM Production.Product P WHERE P.ProductSubcategoryID IN (1,2,3)) as Diff
FROM Production.Product P
WHERE P.ProductSubcategoryID IN (1,2,3))
SELECT CTE_X.Name, CTE_X.Diff
FROM CTE_X
WHERE CTE_X.Diff BETWEEN (-800) AND (-400);

--1.7 : 

-- B1: Đề cho:

SELECT P.FirstName + ' ' + P.LastName
FROM Sales.SalesPerson SP
JOIN HumanResources.Employee E
    ON E.BusinessEntityID  = SP.BusinessEntityID
JOIN Person.Person AS P 
    ON E.BusinessEntityID = P.BusinessEntityID
WHERE Bonus > 5000;

-- B2: Use Subquery

SELECT P.FirstName + ' ' + P.LastName
FROM Person.Person  P 
WHERE P.BusinessEntityID IN (
	SELECT E.BusinessEntityID
	FROM HumanResources.Employee E, Sales.SalesPerson SP 
	WHERE E.BusinessEntityID = SP.BusinessEntityID
	AND SP.Bonus > 5000);

-- B3:
/* Câu Query ở B1 sử dụng 1 Nested Loops, B2 sử dụng 2 Nested Loops
=> B1 tốc độ nhanh hơn B2
*/

--1.8:

-- B1: Write the correlated subquery using EXISTS. 
SELECT S.BusinessEntityID
FROM  Sales.SalesPerson S 
WHERE NOT EXISTS (
	SELECT *
	FROM Sales.Store SS
	WHERE S.BusinessEntityID = SS.SalesPersonID);

-- B2: Write the JOIN equivalent query
SELECT DISTINCT S.BusinessEntityID
FROM Sales.SalesPerson S 
LEFT JOIN Sales.Store SS
ON S.BusinessEntityID = SS.SalesPersonID
WHERE SS.SalesPersonID IS NULL ;

--1.9:
--B1 :

SELECT P.ProductSubcategoryID, COUNT( COALESCE (P.ProductSubcategoryID, -1))
FROM Production.Product  P
GROUP BY P.ProductSubcategoryID;

-- B2: 
--A:
; WITH CTE_TempSet AS (
SELECT P.ProductSubcategoryID AS ProdSubID, COUNT( COALESCE (P.ProductSubcategoryID, -1)) AS CountedProds
FROM Production.Product  P
GROUP BY P.ProductSubcategoryID )
SELECT *
FROM CTE_TempSet

SELECT P.ProductCategoryID AS ProductCategoryID, COUNT( COALESCE (P.ProductSubcategoryID, -1)) AS SubCat, SUM( P.ProductCategoryID) AS SumProds 
FROM Production.ProductSubcategory P
GROUP BY ProductCategoryID

--Exercise 2:

--2.1:

SELECT C.Name Country, S.Name  Province
FROM Person.CountryRegion C, Person.StateProvince S
WHERE C.CountryRegionCode = S.CountryRegionCode;

--2.2:

SELECT C.Name Country, S.Name  Province
FROM Person.CountryRegion C, Person.StateProvince S
WHERE C.CountryRegionCode = S.CountryRegionCode
AND C.Name IN ('Germany', 'Canada');

--2.3:

SELECT S.SalesOrderID, S.OrderDate, S.SalesPersonID, P.BusinessEntityID, P.Bonus, P.SalesYTD
FROM Sales.SalesOrderHeader S, Sales.SalesPerson P
WHERE P.BusinessEntityID = S.SalesPersonID;

--2.4:

SELECT S.SalesOrderID, S.OrderDate, H.JobTitle, P.Bonus, P.SalesYTD
FROM Sales.SalesOrderHeader S, Sales.SalesPerson P, HumanResources.Employee H
WHERE P.BusinessEntityID = S.SalesPersonID
AND H.BusinessEntityID = P.BusinessEntityID;

--2.5:

SELECT S.SalesOrderID, S.OrderDate, PP.FirstName, PP.LastName, P.Bonus 
FROM Sales.SalesOrderHeader S, Sales.SalesPerson P, HumanResources.Employee H, Person.Person PP
WHERE P.BusinessEntityID = S.SalesPersonID
AND P.BusinessEntityID = H.BusinessEntityID
--AND H.BusinessEntityID = P.BusinessEntityID
AND H.BusinessEntityID = PP.BusinessEntityID;

--2.6:

SELECT S.SalesOrderID, S.OrderDate, PP.FirstName, PP.LastName, P.Bonus 
FROM Sales.SalesOrderHeader S, Sales.SalesPerson P, Person.Person PP
WHERE P.BusinessEntityID = S.SalesPersonID
AND P.BusinessEntityID = PP.BusinessEntityID;

--2.7:

SELECT S.SalesOrderID, S.OrderDate, PP.FirstName, PP.LastName
FROM Sales.SalesOrderHeader S, Person.Person PP
WHERE PP.BusinessEntityID = S.SalesPersonID;

--2.8:

SELECT S.SalesOrderID, S.OrderDate, PP.FirstName + ' ' + PP.LastName AS SalesPerson, SS.ProductID, SS.OrderQty
FROM Sales.SalesOrderHeader S, Person.Person PP, Sales.SalesOrderDetail SS
WHERE PP.BusinessEntityID = S.SalesPersonID
AND SS.SalesOrderID = S.SalesOrderID;

--2.9:

SELECT S.SalesOrderID, S.OrderDate, PP.FirstName + ' ' + PP.LastName AS SalesPerson, PRO.Name AS ProductName, SS.OrderQty
FROM Sales.SalesOrderHeader S, Person.Person PP, Sales.SalesOrderDetail SS, Production.Product PRO
WHERE PP.BusinessEntityID = S.SalesPersonID
AND SS.SalesOrderID = S.SalesOrderID
AND PRO.ProductID =SS.ProductID;

--2.10:

SELECT S.SalesOrderID, S.OrderDate, PP.FirstName + ' ' + PP.LastName AS SalesPerson, PRO.Name AS ProductName, SS.OrderQty
FROM Sales.SalesOrderHeader S, Person.Person PP, Sales.SalesOrderDetail SS, Production.Product PRO
WHERE PP.BusinessEntityID = S.SalesPersonID
AND SS.SalesOrderID = S.SalesOrderID
AND PRO.ProductID =SS.ProductID
AND S.SubTotal > 100000
AND DATEPART(YEAR,S.OrderDate) = 2004;

--2.11:

SELECT C.Name Country, S.Name  Province
FROM Person.CountryRegion C
LEFT JOIN Person.StateProvince S
ON C.CountryRegionCode = S.CountryRegionCode
ORDER BY C.Name, S.Name;

--2.12:

SELECT S.CustomerID, SS.SalesOrderID
FROM Sales.Customer S
LEFT JOIN Sales.SalesOrderHeader SS
ON S.CustomerID = SS.CustomerID
WHERE SS.SalesOrderID IS NULL;

-- other way

SELECT S.CustomerID, 'Null' as SalesOrderID
FROM Sales.Customer S
WHERE NOT EXISTS (SELECT * FROM Sales.SalesOrderHeader SS WHERE S.CustomerID = SS.CustomerID);

-- 2.13:
SELECT P.Name AS ProductName, M.Name AS ProductModelName
FROM Production.Product P
FULL OUTER JOIN Production.ProductModel M
ON P.ProductModelID = M.ProductModelID
WHERE P.ProductID IS NULL
OR M.ProductModelID IS NULL;
