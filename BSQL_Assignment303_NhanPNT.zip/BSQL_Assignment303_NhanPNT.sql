CREATE DATABASE EMS;
USE EMS;
GO
-- Create table Employee, Status = 1: are working
CREATE TABLE [dbo].[Employee](
	[EmpNo] [int] NOT NULL
,	[EmpName] [nchar](30) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
,	[BirthDay] [datetime] NOT NULL
,	[DeptNo] [int] NOT NULL
, 	[MgrNo] [int]
,	[StartDate] [datetime] NOT NULL
,	[Salary] [money] NOT NULL
,	[Status] [int] NOT NULL
,	[Note] [nchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
,	[Level] [int] NOT NULL
) ON [PRIMARY]

GO

ALTER TABLE Employee 
ADD CONSTRAINT PK_Emp PRIMARY KEY (EmpNo)
GO

ALTER TABLE [dbo].[Employee]  
ADD  CONSTRAINT [chk_Level] 
	CHECK  (([Level]=(7) OR [Level]=(6) OR [Level]=(5) OR [Level]=(4) OR [Level]=(3) OR [Level]=(2) OR [Level]=(1)))
GO
ALTER TABLE [dbo].[Employee]  
ADD  CONSTRAINT [chk_Status] 
	CHECK  (([Status]=(2) OR [Status]=(1) OR [Status]=(0)))

GO
ALTER TABLE [dbo].[Employee]
ADD Email NCHAR(30) 
GO

ALTER TABLE [dbo].[Employee]
ADD CONSTRAINT chk_Email CHECK (Email IS NOT NULL)
GO

ALTER TABLE [dbo].[Employee] 
ADD CONSTRAINT chk_Email1 UNIQUE(Email)

GO
ALTER TABLE Employee
ADD CONSTRAINT DF_EmpNo DEFAULT 0 FOR EmpNo

GO
ALTER TABLE Employee
ADD CONSTRAINT DF_Status DEFAULT 0 FOR Status

GO
CREATE TABLE [dbo].[Skill](
	[SkillNo] [int] IDENTITY(1,1) NOT NULL
,	[SkillName] [nchar](30) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
,	[Note] [nchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]

GO
ALTER TABLE Skill
ADD CONSTRAINT PK_Skill PRIMARY KEY (SkillNo)

GO
CREATE TABLE [dbo].[Department](
	[DeptNo] [int] IDENTITY(1,1) NOT NULL
,	[DeptName] [nchar](30) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
,	[Note] [nchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]

GO
ALTER TABLE Department
ADD CONSTRAINT PK_Dept PRIMARY KEY (DeptNo)

GO
CREATE TABLE [dbo].[Emp_Skill](
	[SkillNo] [int] NOT NULL
,	[EmpNo] [int] NOT NULL
,	[SkillLevel] [int] NOT NULL
,	[RegDate] [datetime] NOT NULL
,	[Description] [nchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]

GO
ALTER TABLE Emp_Skill
ADD CONSTRAINT PK_Emp_Skill PRIMARY KEY (SkillNo, EmpNo)
GO

ALTER TABLE Employee  
ADD  CONSTRAINT [FK_1] FOREIGN KEY([DeptNo])
REFERENCES Department (DeptNo)

GO
ALTER TABLE Emp_Skill
ADD CONSTRAINT [FK_2] FOREIGN KEY ([EmpNo])
REFERENCES Employee([EmpNo])

GO
ALTER TABLE Emp_Skill
ADD CONSTRAINT [FK_3] FOREIGN KEY ([SkillNo])
REFERENCES Skill([SkillNo])

GO

--1. Add at least 8 records into each created tables.
INSERT INTO Department(DeptName,Note) VALUES
('SPIFFY COMPUTER SERVICE DIV','fixing'),
('PLANNING','maintaince'),
('INFORMATION CENTER',''),
('DEVELOPMENT CENTER',''),
('MANUFACTURING SYSTEMS',''),
('ADMINISTRATION SYSTEMS',''),
('SUPPORT SERVICES','fixing'),
('OPERATIONS','maintaince'),
('SOFTWARE SUPPORT','fixing'),
('BRANCH OFFICE F2','maintaince'),
('BRANCH OFFICE G2','fixing'),
('BRANCH OFFICE H2','maintaince'),
('BRANCH OFFICE I2','fixing'),
('BRANCH OFFICE J2','maintaince'),
('BRANCH OFFICE I3','fixing'),
('BRANCH OFFICE J3','maintaince'),
('BRANCH OFFICE I4',''),
('BRANCH OFFICE J4',''),
('BRANCH OFFICE I5',''),
('BRANCH OFFICE J5','');
GO
INSERT INTO Skill(SkillName,Note) VALUES
('C++','important'),
('.NET','unimportant'),
('Critical Thinking','important'),
('Problem Solving','unimportant'),
('Public Speaking','important'),
('Customer Service Skills','unimportant'),
('Teamwork Skills',''),
('Communication','unimportant'),
('Collaboration','important'),
('Accounting','unimportant'),
('Active Listening','important'),
('Adaptability',''),
('Negotiation','important'),
('Conflict Resolution','unimportant'),
('Empathy','important'),
('Customer Service','unimportant'),
('Decision Making',''),
('Management','important'),
('Leadership skills','unimportant'),
('Organization','');
GO
INSERT INTO Employee(EmpNo,EmpName,BirthDay,DeptNo,MgrNo,StartDate,Salary,Status,Note,Level,Email) VALUES
(1,'Daquan Wise','2000-1-3',1,null,'2021-1-3',10000,1,'good',1,'info@lacco.com.vn'),
(2,'Lance Foley','2003-2-4',3,1,'2021-2-4',11000,1,'not good',2,'info@kllc.com.vn'),
(3,'Graiden Smith','2000-6-5',5,null,'2021-6-5',12000,2,'excellent',3,'thienhuonglogistics@gmail.com'),
(4,'Bernard Parker','2001-4-6',7,2,'2021-4-6',13000,1,'bad',4,'vijaigroupsg@gmail.com'),
(5,'Fuller Jefferson','2002-5-7',9,3,'2021-5-7',14000,1,'',5,'haphuc.8410@gmail.com'),
(6,'Hall Phelps','2003-2-8',1,1,'2021-2-8',15000,1,'',6,'thucnu@idstransport.net'),
(7,'Troy Flowers','2000-2-9',3,3,'2021-2-9',16000,1,'',7,'info@nguyenngoc.vn'),
(8,'Ulysses Woodard','2001-1-10',5,4,'2021-1-10',17000,1,'good',1,'lthanhvan.act@gmail.com'),
(9,'Sebastian Cooley','2002-5-11',7,2,'2021-5-11',18000,1,'not good',2,'steven.vn@pcvn.com.vn'),
(10,'Orlando Tillman','2003-4-12',9,1,'2021-4-12',19000,0,'excellent',3,'vp.daitan@gmail.com'),
(11,'Ethan Gill','2000-1-3',1,4,'2021-1-3',20000,1,'bad',4,'sinh.dir@toannhat.vn'),
(12,'Reuben Walton','2003-2-4',3,2,'2021-2-4',21000,1,'',5,'info@dacologistics.com'),
(13,'Alvin Everett','2000-3-5',5,3,'2021-3-5',22000,1,'',6,'tranngocvinh@yahoo.com.vn'),
(14,'Harlan Guerrero','2001-6-6',7,1,'2021-6-6',23000,1,'good',7,'csoadong@gmail.com'),
(15,'Wylie Roth','2002-5-7',9,1,'2021-5-7',24000,1,'not good',1,'vantaivohongphat@gmail.com'),
(16,'Michael Huber','2003-2-8',1,4,'2021-2-8',25000,1,'excellent',2,'lyphugia10@yahoo.com.vn'),
(17,'Melvin Wheeler','2000-3-9',3,2,'2021-3-9',26000,1,'bad',3,'xuanhieu@xuanhieugroup.com.vn'),
(18,'Kaseem Cobb','2001-1-10',5,2,'2021-1-10',27000,2,'',4,'infocp@chanphat.com.vn'),
(19,'Hyatt Swanson','2002-5-11',7,3,'2021-5-11',28000,0,'',5,'thanhlongfwd@hcm.vnn.vn'),
(20,'Barrett Wagner','2003-1-12',9,4,'2021-1-12',29000,1,'',6,'info@ctctrans.vn');
GO
INSERT INTO Emp_Skill(SkillNo,EmpNo,SkillLevel,RegDate,Description) VALUES
(1,1,1,'2020-1-3',''),
(2,3,2,'2020-2-4',''),
(3,5,3,'2020-6-5','important'),
(4,7,1,'2020-4-6',''),
(5,9,2,'2020-5-7','needed'),
(6,1,3,'2020-2-8',''),
(7,3,1,'2020-2-9',''),
(8,5,2,'2020-1-10','not need'),
(9,7,3,'2020-5-11',''),
(10,9,1,'2020-4-12',''),
(11,1,2,'2020-1-3','not important'),
(12,3,3,'2020-2-4','important'),
(13,5,1,'2020-3-5',''),
(14,7,2,'2020-6-6','needed'),
(15,9,3,'2020-5-7',''),
(16,1,1,'2020-2-8',''),
(17,3,2,'2020-3-9','not need'),
(18,5,3,'2020-1-10',''),
(19,7,1,'2020-5-11',''),
(20,9,2,'2020-1-12','not important');
GO

--2.Specify the name, email and department name of the employees that have been working at least six months.
SELECT E.EmpName,E.Email,D.DeptName, MONTH(GETDATE() - E.StartDate) AS Amount_Month_Working
FROM Employee as E JOIN Department as D
ON E.DeptNo = D.DeptNo
WHERE MONTH(GETDATE() - E.StartDate) >= 6;
GO
--3. Specify the names of the employees whore have either �C++� or �.NET� skills.
SELECT E.EmpName,S.SkillName
FROM Employee AS E
JOIN Emp_Skill AS ES ON E.EmpNo = ES.EmpNo
JOIN Skill AS S ON ES.SkillNo = S.SkillNo
WHERE S.SkillName IN ('C++','.Net');
GO
--4. List all employee names, manager names, manager emails of those employees.
SELECT E1.EmpName, E2.EmpName AS Manager_Name, E2.Email AS Manager_Email
FROM Employee AS E1
JOIN Employee AS E2 ON E1.DeptNo = E2.MgrNo
--5. Specify the departments which have >=2 employees, print out the list of departments� employees right after each department.
SELECT D.DeptName, COUNT(E.DeptNo) AS Amount_Employee
FROM Employee AS E
JOIN Department AS D
ON E.DeptNo = D.DeptNo
GROUP BY D.DeptName
HAVING COUNT(E.DeptNo) >= 2;
GO
--6. List all name, email and number of skills of the employees and sort ascending order by employee�s name.
SELECT E.EmpName, E.Email, COUNT(ES.EmpNo) AS Number_Of_Skill
FROM Employee AS E
JOIN Emp_Skill AS ES
ON E.EmpNo = ES.EmpNo
GROUP BY E.EmpName, E.Email
ORDER BY E.EmpName;
GO
--7. Use SUB-QUERY technique to list out the different employees (include name, email, birthday) who are working and have multiple skills.
SELECT E.EmpName, E.Email, E.BirthDay
FROM Employee AS E
WHERE E.Status = 1 AND E.EmpNo IN (
	SELECT ES.EmpNo
	FROM Emp_Skill AS ES
	GROUP BY ES.EmpNo
	HAVING COUNT(EmpNo) >= 2
	);
GO
--8. Create a view to list all employees are working (include: name of employee and skill name, department name).
CREATE VIEW VIEW_EMPLOYEE
AS
SELECT E.EmpName, S.SkillName, D.DeptName
FROM Employee AS E
JOIN Emp_Skill AS ES ON E.EmpNo = ES.EmpNo
JOIN Skill AS S ON S.SkillNo = ES.SkillNo
JOIN Department AS D ON D.DeptNo = E.DeptNo
WHERE E.Status = 1
GROUP BY E.EmpName, S.SkillName, D.DeptName
GO
SELECT * FROM VIEW_EMPLOYEE;