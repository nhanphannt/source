﻿CREATE DATABASE ASS_302_2;
USE ASS_302_2;
GO
--302.2.1 Create the tables (with the most appropriate field/column constraints & types) and add at least 3 records into each created table.
CREATE TABLE Department 
(
	Department_Number varchar(4) NOT NULL PRIMARY KEY
,	Department_Name varchar(30) NOT NULL
);
GO
CREATE TABLE Skill_Table
(
	Skill_Code varchar(4) NOT NULL PRIMARY KEY
,	Skill_Name varchar(30) NOT NULL
);
GO
CREATE TABLE Employee_Table
(
	Employee_Number varchar(4) NOT NULL PRIMARY KEY
,	Employee_Name varchar(30) NOT NULL
,	Department_Number varchar(4) NOT NULL FOREIGN KEY REFERENCES Department(Department_Number)
);
GO
CREATE TABLE Employee_Skill_Table 
(
	Skill_Code varchar(4) NOT NULL PRIMARY KEY FOREIGN KEY REFERENCES Skill_Table(Skill_Code)
,	Employee_Number varchar(4) NOT NULL FOREIGN KEY REFERENCES Employee_Table(Employee_Number)
,	[Date] date NOT NULL
,	Registered bit NOT NULL
);
GO
INSERT INTO Department(Department_Number,Department_Name) VALUES
('DP01','SPIFFY COMPUTER SERVICE DIV'),
('DP02','PLANNING'),
('DP03','INFORMATION CENTER'),
('DP04','DEVELOPMENT CENTER'),
('DP05','MANUFACTURING SYSTEMS'),
('DP06','ADMINISTRATION SYSTEMS'),
('DP07','SUPPORT SERVICES'),
('DP08','OPERATIONS'),
('DP09','SOFTWARE SUPPORT'),
('DP10','BRANCH OFFICE F2'),
('DP11','BRANCH OFFICE G2'),
('DP12','BRANCH OFFICE H2'),
('DP13','BRANCH OFFICE I2'),
('DP14','BRANCH OFFICE J2'),
('DP15','BRANCH OFFICE I3'),
('DP16','BRANCH OFFICE J3'),
('DP17','BRANCH OFFICE I4'),
('DP18','BRANCH OFFICE J4'),
('DP19','BRANCH OFFICE I5'),
('DP20','BRANCH OFFICE J5');
GO
INSERT INTO Skill_Table(Skill_Code,Skill_Name) VALUES
('SK01','C++'),
('SK02','.NET'),
('SK03','Java'),
('SK04','Problem Solving'),
('SK05','Public Speaking'),
('SK06','Customer Service Skills'),
('SK07','Teamwork Skills'),
('SK08','Communication'),
('SK09','Collaboration'),
('SK10','Accounting'),
('SK11','Active Listening'),
('SK12','Adaptability'),
('SK13','Negotiation'),
('SK14','Conflict Resolution'),
('SK15','Empathy'),
('SK16','Customer Service'),
('SK17','Decision Making'),
('SK18','Management'),
('SK19','Leadership skills'),
('SK20','Organization');
GO
INSERT INTO Employee_Table(Employee_Number,Employee_Name,Department_Number) VALUES
('EP01','Daquan Wise','DP01'),
('EP02','Lance Foley','DP02'),
('EP03','Graiden Smith','DP03'),
('EP04','Bernard Parker','DP04'),
('EP05','Fuller Jefferson','DP05'),
('EP06','Hall Phelps','DP01'),
('EP07','Troy Flowers','DP02'),
('EP08','Ulysses Woodard','DP03'),
('EP09','Sebastian Cooley','DP04'),
('EP10','Orlando Tillman','DP05'),
('EP11','Ethan Gill','DP01'),
('EP12','Reuben Walton','DP02'),
('EP13','Alvin Everett','DP03'),
('EP14','Harlan Guerrero','DP04'),
('EP15','Wylie Roth','DP05'),
('EP16','Michael Huber','DP01'),
('EP17','Melvin Wheeler','DP02'),
('EP18','Kaseem Cobb','DP03'),
('EP19','Hyatt Swanson','DP04'),
('EP20','Barrett Wagner','DP05');
GO
INSERT INTO Employee_Skill_Table (Skill_Code,Employee_Number,Date,Registered) VALUES
('SK01','EP01','2021-1-3',1),
('SK02','EP06','2021-2-4',0),
('SK03','EP11','2021-6-5',1),
('SK04','EP16','2021-4-6',0),
('SK05','EP01','2021-5-7',1),
('SK06','EP06','2021-2-8',0),
('SK07','EP11','2021-2-9',1),
('SK08','EP16','2021-1-10',0),
('SK09','EP01','2021-5-11',1),
('SK10','EP06','2021-4-12',0),
('SK11','EP11','2021-1-3',1),
('SK12','EP16','2021-2-4',0),
('SK13','EP01','2021-3-5',1),
('SK14','EP06','2021-6-6',0),
('SK15','EP11','2021-5-7',1),
('SK16','EP16','2021-2-8',0),
('SK17','EP01','2021-3-9',1),
('SK18','EP06','2021-1-10',0),
('SK19','EP11','2021-5-11',1),
('SK20','EP16','2021-1-12',0);
GO
/*302.2.2 Specify the names of the employees whose have skill of ‘Java’ – give >=2 solutions:              
Use JOIN selection
Use sub query
*/
--way-1
SELECT ET.Employee_Name
FROM Employee_Table AS ET
JOIN Employee_Skill_Table AS EST ON ET.Employee_Number = EST.Employee_Number
JOIN Skill_Table AS ST ON ST.Skill_Code = EST.Skill_Code
WHERE ST.Skill_Name IN ('Java');
--way-2
SELECT ET.Employee_Name
FROM Employee_Table AS ET
WHERE ET.Employee_Number IN (
	SELECT EST.Employee_Number
	FROM Employee_Skill_Table AS EST
	WHERE EST.Skill_Code IN (
		SELECT ST.Skill_Code
		FROM Skill_Table AS ST
		WHERE ST.Skill_Name IN ('Java')
		)
	)
;
--302.2.3 Specify the departments which have >=3 employees, print out the list of departments’ employees right after each department.
SELECT D.Department_Name, ET.Employee_Name
FROM Department AS D
JOIN Employee_Table AS ET
ON D.Department_Number = ET.Department_Number
GROUP BY D.Department_Name, ET.Employee_Name
;
--302.2.4 Use SUB-QUERY technique to list out the different employees (include employee number and employee names) who have multiple skills.
SELECT ET.Employee_Number,ET.Employee_Name
FROM Employee_Table AS ET
WHERE ET.Employee_Number IN (
	SELECT EST.Employee_Number
	FROM Employee_Skill_Table AS EST
	GROUP BY EST.Employee_Number
	HAVING COUNT(Employee_Number) >= 2
	)
;
--302.2.5 Create a view to show different employees (with following information: employee number and employee name, department name) who have multiple skills.
CREATE VIEW View_Employee_MultiSkill AS
SELECT ET.Employee_Number, ET.Employee_Name, D.Department_Name
FROM Employee_Table AS ET
JOIN Employee_SkilView_Employee_MultiSkilll_Table AS EST ON ET.Employee_Number = EST.Employee_Number
JOIN Skill_Table AS ST ON ST.Skill_Code = EST.Skill_Code
JOIN Department AS D ON ET.Department_Number = D.Department_Number
GROUP BY ET.Employee_Number, ET.Employee_Name, D.Department_Name
HAVING COUNT(EST.Employee_Number) >= 2
GO
SELECT * FROM View_Employee_MultiSkill