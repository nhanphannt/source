﻿CREATE DATABASE ASS_302_1;
USE ASS_302_1;
GO
--302.1.1 Create the tables (with the most appropriate field/column constraints & types) and add at least 3 records into each created table.
CREATE TABLE San_Pham
(
	Ma_SP varchar(4) NOT NULL PRIMARY KEY
,	Ten_SP nvarchar(30) NOT NULL
,	Don_Gia int NOT NULL
);
GO
CREATE TABLE Khach_Hang
(
	Ma_KH varchar(4) NOT NULL PRIMARY KEY
,	Ten_KH varchar(30) NOT NULL
,	Phone_No char(10) NOT NULL
,	Ghi_Chu ntext
);
GO
CREATE TABLE Don_Hang
(
	Ma_DH varchar(4) NOT NULL PRIMARY KEY
,	Ngay_DH date NOT NULL
,	Ma_SP varchar(4) NOT NULL FOREIGN KEY REFERENCES San_Pham(Ma_SP)
,	So_Luong int NOT NULL
,	Ma_KH varchar(4) NOT NULL FOREIGN KEY REFERENCES Khach_Hang(Ma_KH)
);
INSERT INTO San_Pham(Ma_SP,Ten_SP,Don_Gia) VALUES
('SP01','Cam',10000),
('SP02','Táo',11000),
('SP03','Chuối',12000),
('SP04','Rau diếp',13000),
('SP05','Cà chua',14000),
('SP06','Sữa ',15000),
('SP07','Phô mai',16000),
('SP08','Trứng',17000),
('SP09','Phô mai tươi',18000),
('SP10','Kem chua',19000),
('SP11','Thịt bò',20000),
('SP12','Gia cầm',21000),
('SP13','Giăm bông',22000),
('SP14','Hải sản',23000),
('SP15','Thịt nguội',24000),
('SP16','Soda',25000),
('SP17','Nước ép',26000),
('SP18','Cà phê',27000),
('SP19','Trà',28000),
('SP20','Nước',29000);
GO
INSERT INTO Khach_Hang(Ma_KH,Ten_KH,Phone_No,Ghi_Chu) VALUES
('KH01','Daquan Wise','0905123456','good'),
('KH02','Lance Foley','0905123457','not good'),
('KH03','Graiden Smith','0905123458','excellent'),
('KH04','Bernard Parker','0905123459','bad'),
('KH05','Fuller Jefferson','0905123460',''),
('KH06','Hall Phelps','0905123461',''),
('KH07','Troy Flowers','0905123462',''),
('KH08','Ulysses Woodard','0905123463','good'),
('KH09','Sebastian Cooley','0905123464','not good'),
('KH10','Orlando Tillman','0905123465','excellent'),
('KH11','Ethan Gill','0905123466','bad'),
('KH12','Reuben Walton','0905123467',''),
('KH13','Alvin Everett','0905123468',''),
('KH14','Harlan Guerrero','0905123469','good'),
('KH15','Wylie Roth','0905123470','not good'),
('KH16','Michael Huber','0905123471','excellent'),
('KH17','Melvin Wheeler','0905123472','bad'),
('KH18','Kaseem Cobb','0905123473',''),
('KH19','Hyatt Swanson','0905123474',''),
('KH20','Barrett Wagner','0905123475','');
GO
INSERT INTO Don_Hang (Ma_DH,Ngay_DH,Ma_SP,So_Luong,Ma_KH) VALUES
('DH01','2021-1-3','SP01',1,'KH01'),
('DH02','2021-2-4','SP02',2,'KH02'),
('DH03','2021-6-5','SP03',3,'KH03'),
('DH04','2021-4-6','SP04',4,'KH04'),
('DH05','2021-5-7','SP05',5,'KH05'),
('DH06','2021-2-8','SP06',6,'KH01'),
('DH07','2021-2-9','SP07',7,'KH02'),
('DH08','2021-1-10','SP08',8,'KH03'),
('DH09','2021-5-11','SP09',9,'KH04'),
('DH10','2021-4-12','SP10',10,'KH05'),
('DH11','2021-1-3','SP01',11,'KH01'),
('DH12','2021-2-4','SP02',12,'KH02'),
('DH13','2021-3-5','SP03',13,'KH03'),
('DH14','2021-6-6','SP04',14,'KH04'),
('DH15','2021-5-7','SP05',15,'KH05'),
('DH16','2021-2-8','SP06',16,'KH01'),
('DH17','2021-3-9','SP07',17,'KH02'),
('DH18','2021-1-10','SP08',18,'KH03'),
('DH19','2021-5-11','SP09',19,'KH04'),
('DH20','2021-1-12','SP10',20,'KH05');
GO
--302.1.2. Create an order slip VIEW which has the same number of lines as the Don_Hang, with the following information: Ten_KH, Ngay_DH, Ten_SP, So_Luong, Thanh_Tien
CREATE VIEW View_Don_Hang AS
SELECT K.Ten_KH, D.Ngay_DH, S.Ten_SP, D.So_Luong, S.Don_Gia*D.So_Luong AS Thanh_Tien
FROM Don_Hang AS D
JOIN Khach_Hang AS K ON D.Ma_KH = K.Ma_KH
JOIN San_Pham AS S ON D.Ma_SP = S.Ma_SP
GO
SELECT * FROM View_Don_Hang;

